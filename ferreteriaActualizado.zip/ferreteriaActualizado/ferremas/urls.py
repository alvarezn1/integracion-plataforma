from django.urls import path
from . import views

urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('herramientas/',views.herramientas, name='herramientas'),
]
