from django.shortcuts import render


def inicio(request):
    return render(request, 'ferremas/inicio.html')

def herramientas(request):
    return render(request, 'ferremas/herramientas.html')
# Create your views here.
